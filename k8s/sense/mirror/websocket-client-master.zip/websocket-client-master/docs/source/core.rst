##################
websocket/_core.py
##################

The _core.py file

.. automodule:: websocket._core
  :members:
