############
Installation
############

First, install the following dependencies:
  - six
  - backports.ssl_match_hostname (only for Python 2.x)

To install the Python 2 dependencies, use:
``pip install six backports.ssl_match_hostname``

To install the Python 3 dependencies, use:
``pip install six``

You can use either ``python setup.py install`` or
``pip install websocket-client`` to install this library.
