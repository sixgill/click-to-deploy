#################
websocket/_url.py
#################

The _url.py file

.. automodule:: websocket._url
  :members:
