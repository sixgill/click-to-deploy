#################
websocket/_app.py
#################

The _app.py file

.. automodule:: websocket._app
  :members:
